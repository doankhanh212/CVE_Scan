import tempfile
from pathlib import Path
import sys, os
# ensure project root is on sys.path when running tests directly
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from modules.scanners.auth_linux_scanner import AuthLinuxScanner
from modules.report.csv_report import export_csv

# Test Auth alias
class Dummy(AuthLinuxScanner):
    def get_installed_packages(self):
        return [("pkg1","1.0")]


d = Dummy("127.0.0.1","user")
assert hasattr(d, "get_installed_software")
assert d.get_installed_software() == d.get_installed_packages()

# Test CSV export
report = {
    "meta": {},
    "hosts": [
        {
            "target": "1.2.3.4",
            "scan_type": "basic",
            "summary": {},
            "services": [
                {"name":"http:80","product":"nginx","version":"1.18","port":80,"protocol":"tcp","os":None}
            ],
            "vulnerabilities": [
                {"cve_id":"CVE-2023-1234","service":"http:80","cpe":"cpe:...","description":"desc","severity":{"label":"HIGH","score":7.5},"cvss4":{},"references":[],"evidence":{"product":"nginx","version":"1.18","os":None}}
            ]
        }
    ]
}

with tempfile.TemporaryDirectory() as tmp:
    out = Path(tmp)/"out.csv"
    ok = export_csv(report, str(out))
    assert ok
    content = out.read_text(encoding='utf-8')
    assert "CVE-2023-1234" in content

print("Local tests passed")
