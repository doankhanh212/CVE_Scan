import os
import shutil

V1_PATH = os.path.join('modules', 'V1')

KEEP = set([
    'nvd_data', # data may be kept elsewhere
])


def audit_v1():
    if not os.path.exists(V1_PATH):
        print('modules/V1 not found')
        return

    print('Files and directories in modules/V1:')
    for root, dirs, files in os.walk(V1_PATH):
        for name in files:
            print(os.path.join(root, name))
    print('\nSuggested safe actions:')
    print(' - Ensure tests pass and local DB is present at modules/V1/nvd_cve.db or migrated location')
    print(' - Backup modules/V1/* to a tarball before removal')
    print(' - Remove modules/V1 when ready')


def remove_v1(confirm=False):
    if not os.path.exists(V1_PATH):
        print('modules/V1 not found')
        return

    if not confirm:
        print('Pass confirm=True to actually remove modules/V1')
        return

    # safe remove
    shutil.rmtree(V1_PATH)
    print('modules/V1 removed')


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--remove', action='store_true')
    args = p.parse_args()
    audit_v1()
    if args.remove:
        print('To remove run: python scripts/cleanup_v1.py --remove (will delete modules/V1)')
